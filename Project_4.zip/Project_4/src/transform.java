public interface transform {
    boolean transform(WorldModel world, EventScheduler scheduler, ImageStore imageStore);

}
