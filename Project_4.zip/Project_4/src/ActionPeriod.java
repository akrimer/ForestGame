public interface ActionPeriod {
    double getActionPeriod();


}
