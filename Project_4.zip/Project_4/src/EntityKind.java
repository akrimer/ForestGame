
enum EntityKind {
    HOUSE, DUDE_FULL, DUDE_NOT_FULL, OBSTACLE, FAIRY, STUMP, SAPLING, TREE, Banzo, DudeDogFull, DudeDogNotFull
}

