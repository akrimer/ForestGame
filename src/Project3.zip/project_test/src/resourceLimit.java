public interface    resourceLimit {
    int getResourceLimit();
}
