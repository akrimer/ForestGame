enum ActionKind {
    ACTIVITY, ANIMATION
}
